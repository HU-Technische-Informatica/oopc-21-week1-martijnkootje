// main.cpp

// It is generally recommended to have a single file provide the main
// of a testing binary, and other test files to link against it.

#define CATCH_CONFIG_MAIN  // This tells Catch to provide a main() - only do this in one cpp file
#include "catch.hpp"